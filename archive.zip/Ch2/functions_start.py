#
# Example file for working with functions
#

# define a basic function
def function1():
    print("I am a function")

# function that takes arguments
def funcArea(arg1, arg2):
    print(arg1*arg2) 

# function that returns a value
def mult(x):
    return x*x


# function with default value for an argument
def power(num, x=1):
    result=1
    for i in range(x):
        result=result*num
    return result

#function with variable number of arguments
def multi_add(*args):
    result=0
    for x in args:
        result=result + x
    return result

# function1()
# print(function1())
# print(function1)
# funcArea(2,3)
# print(funcArea(4,5))
# print(mult(12))
print(power(2))
print(power(2,3))
print(power(num=2))
print(multi_add(10,50,20,100,20,100))