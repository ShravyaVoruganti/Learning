#
# Example file for working with classes
#
class myClass():
  def method1(self):
    print("Method1 Class1")
  def method2(self, someString):
    print("Method2 Class1 ",someString)
class Class2(myClass):
  def method1(self):
    myClass.method1(self)
    print("Method1 Class2")
  def method2(self, someString):
    print("Method2 Class2 ",someString)

def main():
  c=myClass()
  c.method1()
  c.method2("This is a string")
  c2=Class2()
  c2.method1()
  c2.method2("This is a string")
  
if __name__ == "__main__":
  main()
